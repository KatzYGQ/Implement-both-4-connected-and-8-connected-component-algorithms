#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include<limits>
using namespace std;

struct Property {
    int label, numPixels, minR, minC, maxR, maxC;
};

class ccLabel {
public:
    int numRows, numCols, minVal, maxVal, newLabel, trueNumCC, newMin, newMax;
    int** zeroFramedAry;
    int* NonZeroNeighborAry;
    int* EQAry;
    char option;
    Property* CCproperty;

    ccLabel(string inFile, char option) {
        ifstream input(inFile);
        if (!input) {
            cerr << "Error opening input file!" << endl;
            exit(1);
        }
        this->option = option;
        input >> numRows >> numCols >> minVal >> maxVal;
        zeroFramedAry = new int* [numRows + 2];
        for (int i = 0; i < numRows + 2; ++i) {
            zeroFramedAry[i] = new int[numCols + 2]();
        }
        EQAry = new int[(numRows * numCols) / 4];
        for (int i = 0; i < (numRows * numCols) / 4; ++i) {
            EQAry[i] = i;
        }
        NonZeroNeighborAry = new int[5];
        newLabel = 0;
        trueNumCC = 0;
        newMin = 0;
        newMax = 0;
        zero2D(zeroFramedAry, numRows, numCols);
        loadImage(input);
        input.close();
    }

    void zero2D(int** array, int numRows, int numCols) {
        for (int i = 0; i < numRows + 2; i++) {
            fill(array[i], array[i] + numCols + 2, 0);
        }
    }

    void negative1D(int* array, int size) {
        fill(array, array + size, -1);
    }

    void loadImage(ifstream& input) {
        string line;
        int pixelValue, row = 1;

       
        getline(input, line); 

        while (getline(input, line)) {
            stringstream ss(line);
            int col = 1;
            while (ss >> pixelValue) {
                zeroFramedAry[row][col++] = pixelValue;
            }
            row++;
        }

       
        if (option == 'y' || option == 'Y') {
            conversion();
        }
    }

    void conversion() {
        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= numCols; j++) {
                zeroFramedAry[i][j] = 1 - zeroFramedAry[i][j]; // Flip 0 to 1 and 1 to 0
            }
        }
    }

    void imgReformat(ofstream& RFprettyPrintFile, const string& caption) {
        RFprettyPrintFile << caption << endl;
        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= numCols; j++) {
                if (zeroFramedAry[i][j] < 10) // Single-digit numbers
                    RFprettyPrintFile << zeroFramedAry[i][j] << "  "; // Print with extra space for alignment
                else
                    RFprettyPrintFile << zeroFramedAry[i][j] << " "; // Print normally for double-digit numbers
            }
            RFprettyPrintFile << endl;
        }
        RFprettyPrintFile << endl; // Extra line for spacing between different stages
    }



    void connect8Pass1() {
        newLabel = 0;
        for (int i = 1; i <= numRows; ++i) {
            for (int j = 1; j <= numCols; ++j) {
                if (zeroFramedAry[i][j] > 0) { // Foreground pixel
                    // Consider 8-connectivity neighbors that are available in Pass 1
                    int northWest = zeroFramedAry[i - 1][j - 1];
                    int north = zeroFramedAry[i - 1][j];
                    int northEast = zeroFramedAry[i - 1][j + 1];
                    int west = zeroFramedAry[i][j - 1];

                    // Initialize minLabel to a high value before finding the minimum
                    int minLabel = numeric_limits<int>::max();
                    minLabel = min(minLabel, northWest > 0 ? northWest : minLabel);
                    minLabel = min(minLabel, north > 0 ? north : minLabel);
                    minLabel = min(minLabel, northEast > 0 ? northEast : minLabel);
                    minLabel = min(minLabel, west > 0 ? west : minLabel);

                    if (minLabel == numeric_limits<int>::max()) { // No foreground neighbors
                        zeroFramedAry[i][j] = ++newLabel;
                    }
                    else {
                        zeroFramedAry[i][j] = minLabel;
                        // Update equivalencies for neighbors not equal to minLabel
                        if (northWest > 0 && northWest != minLabel) EQAry[northWest] = minLabel;
                        if (north > 0 && north != minLabel) EQAry[north] = minLabel;
                        if (northEast > 0 && northEast != minLabel) EQAry[northEast] = minLabel;
                        if (west > 0 && west != minLabel) EQAry[west] = minLabel;
                    }
                }
            }
        }
    }


    void connect8Pass2() {
        for (int i = numRows; i > 0; --i) {
            for (int j = numCols; j > 0; --j) {
                if (zeroFramedAry[i][j] > 0) { // Check only foreground pixels
                    int neighbors[] = {
                        zeroFramedAry[i][j + 1],     // East
                        zeroFramedAry[i + 1][j + 1], // South-East
                        zeroFramedAry[i + 1][j],     // South
                        zeroFramedAry[i + 1][j - 1]  // South-West
                    };

                    int minLabel = std::numeric_limits<int>::max();
                    for (int k = 0; k < 4; ++k) {
                        if (neighbors[k] > 0) {
                            minLabel = std::min(minLabel, EQAry[neighbors[k]]);
                        }
                    }

                    if (minLabel < zeroFramedAry[i][j]) {
                        zeroFramedAry[i][j] = minLabel;
                        EQAry[zeroFramedAry[i][j]] = minLabel; // Update EQAry for the current label
                    }
                }
            }
        }
    }



    void connect4Pass1() {
        newLabel = 0; // Resetting newLabel for this pass

        for (int i = 1; i <= numRows; ++i) {
            for (int j = 1; j <= numCols; ++j) {
                if (zeroFramedAry[i][j] > 0) { // Foreground pixel
                    // Examine only the North and West neighbors for 4-connectivity
                    int north = zeroFramedAry[i - 1][j];
                    int west = zeroFramedAry[i][j - 1];

                    if (north == 0 && west == 0) { // No connected neighbors, assign a new label
                        zeroFramedAry[i][j] = ++newLabel;
                    }
                    else { // One or both neighbors are foreground, assign the smallest label
                        int minLabel = std::min(north > 0 ? north : newLabel, west > 0 ? west : newLabel);
                        zeroFramedAry[i][j] = minLabel;

                        // Update equivalency array if necessary
                        if (north > 0 && west > 0 && north != west) {
                            EQAry[std::max(north, west)] = minLabel;
                        }
                    }
                }
            }
        }
    }

    void connect4Pass2() {
        for (int i = numRows; i > 0; --i) {
            for (int j = numCols; j > 0; --j) {
                if (zeroFramedAry[i][j] > 0) { // Foreground pixel
                    // Examine the South and East neighbors for 4-connectivity
                    int south = zeroFramedAry[i + 1][j];
                    int east = zeroFramedAry[i][j + 1];

                    // Find the minimum label among the current pixel and its South and East neighbors
                    int currentLabel = zeroFramedAry[i][j];
                    int minLabel = currentLabel;

                    if (south > 0) {
                        minLabel = min(minLabel, EQAry[south]);
                    }
                    if (east > 0) {
                        minLabel = min(minLabel, EQAry[east]);
                    }

                    // Update the current pixel's label to the minimum label found
                    zeroFramedAry[i][j] = EQAry[minLabel];

                    // Update the equivalency array
                    EQAry[currentLabel] = EQAry[minLabel];
                }
            }
        }

        // At the end of Pass 2, update the equivalency array to ensure all labels point to the smallest equivalent label
        for (int label = 1; label <= newLabel; ++label) {
            EQAry[label] = EQAry[EQAry[label]];
        }
    }

   
    void connectPass3( ) {
        

        for (int i = 1; i <= trueNumCC; ++i) {
            CCproperty[i].label = i;
            CCproperty[i].numPixels = 0;
            CCproperty[i].minR = numRows;
            CCproperty[i].maxR = 0;
            CCproperty[i].minC = numCols;
            CCproperty[i].maxC = 0;
        }

        for (int i = 1; i <= numRows; ++i) {
            for (int j = 1; j <= numCols; ++j) {
                if (zeroFramedAry[i][j] > 0) {
                    int label = EQAry[zeroFramedAry[i][j]];
                    zeroFramedAry[i][j] = label;

                    CCproperty[label].numPixels++;
                    if (i < CCproperty[label].minR) CCproperty[label].minR = i;
                    if (i > CCproperty[label].maxR) CCproperty[label].maxR = i;
                    if (j < CCproperty[label].minC) CCproperty[label].minC = j;
                    if (j > CCproperty[label].maxC) CCproperty[label].maxC = j;
                }
            }
        }

        
    }



    int manageEQAry() {
        int trueNumCC = 0;
        for (int i = 1; i <= newLabel; ++i) {
            if (EQAry[i] == i) { // Root label
                EQAry[i] = ++trueNumCC; // Assign a new component number
            }
            else { // Equivalent label
                EQAry[i] = EQAry[EQAry[i]]; // Collapse to root label
            }
        }
        return trueNumCC; // Return the total number of unique labels/components
    }



    void printCCproperty(ofstream& propertyFile) {
        
        propertyFile << numRows << " " << numCols << " " << minVal << " " << maxVal << endl;

        
        propertyFile << trueNumCC << endl;

        for (int i = 1; i <= trueNumCC; ++i) {
            
            propertyFile << i << endl 
                << CCproperty[i].numPixels << endl 
                << CCproperty[i].minR << " " << CCproperty[i].minC << endl // Upper left corner
                << CCproperty[i].maxR << " " << CCproperty[i].maxC << endl; // Lower right corner
        }
    }




    void printEQAry(ofstream& outFile) {
        outFile << "Eq Table\n";
        for (int i = 1; i <= newLabel; ++i) {
            outFile << EQAry[i] << (i % 20 == 0 ? "\n" : " ");
        }
        outFile <<"\n"<< endl;
    }

    void drawBoxes() {
        
        for (int i = 1; i <= trueNumCC; ++i) {
            int minR = CCproperty[i].minR;
            int maxR = CCproperty[i].maxR;
            int minC = CCproperty[i].minC;
            int maxC = CCproperty[i].maxC;
            for (int row = minR; row <= maxR; ++row) {
                zeroFramedAry[row][minC] = zeroFramedAry[row][maxC] = i;
            }
            for (int col = minC; col <= maxC; ++col) {
                zeroFramedAry[minR][col] = zeroFramedAry[maxR][col] = i;
            }
        }
    }

    void printImg(ofstream& labelFile) {
        labelFile << numRows << " " << numCols << " " << newMin << " " << newMax << endl;
        for (int i = 1; i <= numRows; ++i) {
            for (int j = 1; j <= numCols; ++j) {
                labelFile << zeroFramedAry[i][j] << " ";
            }
            labelFile << endl;
        }
    }



    void connected4(ofstream& RFprettyPrintFile, ofstream& deBugFile) {
        deBugFile << "Entering connected4 method\n";
        
        connect4Pass1();
        deBugFile << "In connected4 pass1, newLabel " << newLabel << "\n\n";
        imgReformat(RFprettyPrintFile, "After connect4Pass1");
        printEQAry(RFprettyPrintFile);
        connect4Pass2();
        deBugFile << "In connected4 pass2, newLabel= " << newLabel << "\n\n";
        imgReformat(RFprettyPrintFile, "After connect4Pass2");
        printEQAry(RFprettyPrintFile);
        trueNumCC = manageEQAry(); 
        deBugFile << "In connected4, after manage EQAry, trueNumCC=" << trueNumCC << "\n\n";
        connectPass3();
        imgReformat(RFprettyPrintFile, "After connectPass3");
        printEQAry(RFprettyPrintFile);
        RFprettyPrintFile << "Bounding Boexs\n";
        drawBoxes();
        printImg(RFprettyPrintFile);
        deBugFile << "Leaving connected4 method\n";
    }


    void connected8(ofstream& RFprettyPrintFile, ofstream& deBugFile) {
        RFprettyPrintFile << "HELLO\n";
        deBugFile << "Entering connected8 method\n";
        connect8Pass1();
        deBugFile << "In connected8 pass1, newLabel " << newLabel << "\n\n";
        imgReformat(RFprettyPrintFile, "After connect8Pass1");
        printEQAry(RFprettyPrintFile);
        connect8Pass2();
        deBugFile << "In connected8 pass2, newLabel= " << newLabel << "\n\n";
        imgReformat(RFprettyPrintFile, "After connect8Pass2");
        printEQAry(RFprettyPrintFile);
        trueNumCC = manageEQAry(); 
        deBugFile << "In connected8, after manage EQAry, trueNumCC=" << trueNumCC << "\n\n";
        manageEQAry();
        connectPass3();
        imgReformat(RFprettyPrintFile, "After connectPass3");
        printEQAry(RFprettyPrintFile);
        RFprettyPrintFile << "Bounding Boexs\n";
        drawBoxes();
        printImg(RFprettyPrintFile);
        deBugFile << "Leaving connected8 method\n";
    }

};


int main(int argc, char* argv[]) {
    if (argc != 5) {
        cerr << "Usage: " << argv[0] << " <inputImage.txt> <connectness> <conversion> <outputFilePrefix>" << endl;
        return 1;
    }

    string inputFileName = argv[1];
    int connectness = stoi(argv[2]);
    char conversion = argv[3][0]; // Assumes 'y' or 'n'
    string outputFilePrefix = argv[4];

    
    ofstream RFprettyPrintFile(outputFilePrefix + "_RFprettyPrint.txt");
    ofstream labelFile(outputFilePrefix + "_label.txt");
    ofstream propertyFile(outputFilePrefix + "_property.txt");
    ofstream deBugFile(outputFilePrefix + "_debug.txt");

 
    if (!RFprettyPrintFile || !labelFile || !propertyFile || !deBugFile) {
        cerr << "Error opening output files." << endl;
        return 1;
    }


    ccLabel labeler(inputFileName, conversion);


    

    if (connectness == 4) {
        labeler.connected4(RFprettyPrintFile, deBugFile);
    }
    else if (connectness == 8) {
        labeler.connected8(RFprettyPrintFile, deBugFile);
    }
    else {
        cerr << "Invalid connectivity option. Please choose 4 or 8." << endl;
        return 1;
    }

   
    labeler.printImg(labelFile);
    labeler.printCCproperty(propertyFile);
    labeler.printEQAry(deBugFile);
    labeler.drawBoxes(); 
    
    
    RFprettyPrintFile.close();
    labelFile.close();
    propertyFile.close();
    deBugFile.close();

    return 0;
}
